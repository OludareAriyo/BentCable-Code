# Simulation study for joint Modelling of  Bent-cable mixed model with survival analysis.
#We generate data from mixture of 2 component normal distributions for  random effects  
#and analysis with mixture of normal distributions with 2 components. 
#Needed library
options("install.lock"=FALSE)
library("sn")
library("mvtnorm")
library("rjags")
library("lme4")
library("mcmcplots")
# working directory
setwd("")
########################################
#Parameters
n=500 #number of sample sizes
t=5 # number of time points
beta11=2
beta12=-1
beta13=3
taum=1
gammam=0.3
beta21=2
beta22=5
r=2
ph1=ph2=ph3=ph4=ph5=1.5
pi1=0.4
pi2=0.6
########Simulate Covariate ################
set.seed(122)
x <- rep(runif(n,-1,4),each=t)
id <- sort(rep(1:n,t))
###############################
# Simulate homogeneous random effects with 5 components
Sigmab = c(1, 0.5, 0.5, 0.5, 0.5, 0.5, 1,
           0.5, 0.5, 0.5, 0.5, 0.5, 
           1, 0.5, 0.5, 0.5, 0.5, 0.5, 
           1, 0.5, 0.5, 0.5, 0.5, 0.5, 1)
Sigmab = matrix(Sigmab,5,5)
b1<-rmvnorm(n,rep(1,5),Sigmab)
b2<-rmvnorm(n,rep(-1,5),Sigmab)
#Heterogenous random effect with two components
b<-pi1*b1+pi2*b2

#Simulate the individual intercept and slope
beta1i<-rep(beta11+b[,1],each=t)
beta2i<--rep(beta12+b[,2],each=t)
beta3i<-rep(beta13+b[,3],each=t)
taui<-rep(taum+b[,4],each=t)
gammai<-rep(gammam+b[,5],each=t)
#################### The Bent-Cable##########
qx<- (((x-taui+gammai)^2)/(4*gammai)*ifelse(abs(x-taui)<=gammai,1,0))+((x-taui)*ifelse(x>gammai,1,0))
######### The mean of longitudinal part########
mean.y<-beta1i+beta2i*x+beta3i*qx
#Simulating the longitudinal data 
set.seed(4555)
ygen <- rsn(n*t, mean.y, sqrt(0.5),5) 

#########Weibul #####################
h.t<- log(r)+(beta21+beta22*x+ph1*b[,1]+ph2*b[,2]+ph3*b[,3]+ph4*b[,4]+ph5*b[,5])
#############Cencuring##############
# censoring times
set.seed(4755)
Ci <- rep(rexp(n,0.5),each=t)
# Follow-up times and event indicators
time <- pmin(h.t, Ci)
status <- as.numeric(h.t <=Ci)
##################### Data Frame ##################
simdata=data.frame(y=ygen,x=x,surt=h.t,status=status,id)
jdata <- list(y=c(simdata$y), x=c(simdata$x),
              status=c(simdata$status),
              id=c(simdata$id), K=length(simdata$y), 
              n=max(simdata$id),
              R=diag(c(1,1,1,1,1))) 

###################################################
jags.inits <- function(){list(beta11=2,beta12=-1,beta21=2,beta22=5,
                              beta13=3,ph1=1.5,ph2=1.5,ph3=1.5,
                              ph4= 1.5,ph5=1.5,r=2,
                              taum=1,gammam=0.3,
                              tauz=rchisq(1,8),deltae=4)}

results <-jags.model(file="M2.txt",
                     data=jdata,inits=jags.inits, 
                     n.chains = 3)

update(results, n.iter=20000,
       n.burn=10000,thin=10)

output<- coda.samples(results, c("beta11","beta12","beta13","beta21","beta22",
                                 "ph1","ph2","ph3", "ph4", "ph5","taum","gammam","r",
                                 "deltae", "sigmae","sigmab","pi1","pi2"), 
                      n.iter=20000,n.burn=10000,thin=10)

gelman.diag(output, multivariate = FALSE)


post.repli <-summary(output)

